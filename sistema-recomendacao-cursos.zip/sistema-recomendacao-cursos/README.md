# 🎓 Sistema de Recomendação de Cursos Gratuitos

Este projeto tem como objetivo oferecer recomendações personalizadas de cursos gratuitos para pessoas de baixa renda no Brasil, com foco em acessibilidade educacional e autonomia no aprendizado.

## 💡 Motivação

Muitas pessoas com baixa renda têm dificuldade de acesso a conteúdos educacionais relevantes e gratuitos. Pensando nisso, desenvolvemos um sistema que, com base nas preferências de um curso escolhido, sugere outros cursos similares, facilitando a descoberta de novas oportunidades.

## 🛠️ Tecnologias Utilizadas

- Python 3
- Google Colab
- Pandas
- Numpy
- Seaborn / Matplotlib
- Scikit-learn (LabelEncoder e Cosine Similarity)

## 📁 Estrutura do Projeto

```
📦sistema-recomendacao-cursos
 ┣ 📊 cursos.csv
 ┣ 📓 PROJETOAPLICIII.ipynb
 ┗ 📄 README.md
```

## ⚙️ Como Executar

1. Clone este repositório:
   ```bash
   git clone https://github.com/seu-usuario/sistema-recomendacao-cursos.git
   ```
2. Abra o notebook `PROJETOAPLICIII.ipynb` no Google Colab.
3. Faça o upload do arquivo `cursos.csv` no ambiente do Colab.
4. Execute as células passo a passo para visualizar os dados e gerar recomendações.

## 🧠 Lógica do Sistema

O sistema funciona da seguinte forma:

1. **Pré-processamento dos dados**: os dados categóricos do dataset de cursos são transformados usando o `LabelEncoder`.
2. **Cálculo de similaridade**: usamos a **similaridade do cosseno** para comparar cursos com base em atributos como área, plataforma e avaliação.
3. **Geração de recomendações**: o usuário seleciona um curso e o sistema retorna os cursos mais semelhantes com base na pontuação de similaridade.

## 📊 Visualizações

Algumas visualizações foram geradas para entender melhor a distribuição dos cursos:
- Gráfico de barras por plataforma
- Gráfico de contagem por área
- Gráfico de cursos por avaliação

## 🔁 Exemplo de Recomendação

```python
curso_referencia = 'Introdução à Programação com Python'
recomendacoes = recomendar_cursos(curso_referencia, df, cosine_sim)
print(recomendacoes)
```

## 👩‍💻 Autora

- **Laura [Lau]** – Estudante de Ciência de Dados e autora deste projeto.
- Projeto desenvolvido como trabalho final da disciplina *Projeto Aplicado II*.

## 📄 Licença

Este projeto está licenciado sob a Licença MIT — veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 💬 Contato

Entre em contato pelo [LinkedIn](https://www.linkedin.com/) ou crie uma issue neste repositório.
